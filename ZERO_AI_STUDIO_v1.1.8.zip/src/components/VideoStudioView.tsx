import { useEffect, useState } from 'react';
import { AlertTriangle, Download, Film, Loader2, Music, Play } from 'lucide-react';
import { renderTimelineVideoMax60s, type VideoRenderResult } from '../lib/localVideoCompositor.ts';
import type { FilmScene, StudioProject } from '../types/zero.ts';

interface VideoStudioViewProps {
  projects: StudioProject[];
  activeProjectId?: string;
  soundtrack?: { url: string; title: string } | null;
}

export function VideoStudioView({ projects, activeProjectId, soundtrack }: VideoStudioViewProps) {
  const [selectedProjectId, setSelectedProjectId] = useState(
    activeProjectId || projects[0]?.id || ''
  );
  const currentProject = projects.find((p) => p.id === selectedProjectId) ?? projects[0];

  const [scenes, setScenes] = useState<FilmScene[]>(currentProject?.scenes ?? []);
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [burnSubtitles, setBurnSubtitles] = useState(true);
  const [includeVoiceovers, setIncludeVoiceovers] = useState(true);
  const [selectedAudioUrl, setSelectedAudioUrl] = useState<string>(soundtrack?.url ?? '');
  const [rendering, setRendering] = useState(false);
  const [progress, setProgress] = useState({ pct: 0, label: '' });
  const [result, setResult] = useState<VideoRenderResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (currentProject) {
      setScenes(currentProject.scenes);
    }
  }, [selectedProjectId, currentProject]);

  useEffect(() => {
    if (soundtrack?.url) {
      setSelectedAudioUrl(soundtrack.url);
    }
  }, [soundtrack]);

  const projectAudioAssets = (currentProject?.assets ?? []).filter(
    (a) => a.type === 'music' || a.type === 'audio'
  );
  const hasVoiceoverCount = scenes.filter((s) => Boolean(s.audioDataUrl)).length;

  const totalDuration = scenes.reduce((sum, s) => sum + s.durationSec, 0);
  const exceedsLimit = totalDuration > 60;

  function updateSceneDuration(id: string, val: number) {
    const safeVal = Math.max(3, Math.min(30, val));
    setScenes((prev) => prev.map((s) => (s.id === id ? { ...s, durationSec: safeVal } : s)));
  }

  function updateCamera(id: string, movement: FilmScene['cameraMovement']) {
    setScenes((prev) =>
      prev.map((s) => (s.id === id ? { ...s, cameraMovement: movement } : s))
    );
  }

  function clampTo58Seconds() {
    if (!scenes.length) return;
    const target = 58;
    const current = scenes.reduce((sum, s) => sum + s.durationSec, 0);
    if (current <= 60) return;
    const ratio = target / current;
    let sum = 0;
    setScenes((prev) =>
      prev.map((s, idx) => {
        if (idx === prev.length - 1) {
          return { ...s, durationSec: Math.max(4, target - sum) };
        }
        const d = Math.max(4, Math.floor(s.durationSec * ratio));
        sum += d;
        return { ...s, durationSec: d };
      })
    );
  }

  async function handleExportVideo() {
    if (exceedsLimit || rendering || !scenes.length) return;
    setRendering(true);
    setError(null);
    setProgress({ pct: 2, label: 'Initialisiere Video-Pipeline...' });
    try {
      const rendered = await renderTimelineVideoMax60s({
        scenes,
        aspectRatio,
        burnSubtitles,
        audioUrl: selectedAudioUrl || undefined,
        includeSceneVoiceovers: includeVoiceovers,
        onProgress: (pct, label) => setProgress({ pct, label }),
      });
      setResult(rendered);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Videoexport fehlgeschlagen');
    } finally {
      setRendering(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-white">ZERO VIDEO STUDIO</h1>
          <p className="text-xs text-slate-400 mt-1">
            Szenen-Schnitt, Ken-Burns Kamerabewegung, Untertitel & Export · Harte Grenze: max. 60 Sekunden
          </p>
        </div>

        <select
          value={selectedProjectId}
          onChange={(e) => setSelectedProjectId(e.target.value)}
          className="min-h-[44px] bg-[#11151E] border border-white/[0.1] rounded-xl px-3.5 text-sm text-white focus:outline-none focus:border-[#2563EB]"
        >
          {projects.map((p) => (
            <option key={p.id} value={p.id}>
              Projekt: {p.title}
            </option>
          ))}
        </select>
      </div>

      {/* 60s Duration Guard Bar */}
      <div className="bg-[#11151E] border border-white/[0.08] rounded-2xl p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-sm font-medium text-white">
            Schnitt-Laufzeit (Zielbereich 55–60 Sekunden)
          </span>
          <span
            className={`text-sm font-mono tabular-nums font-semibold ${
              exceedsLimit ? 'text-rose-400' : totalDuration >= 55 ? 'text-emerald-400' : 'text-sky-400'
            }`}
          >
            {totalDuration.toFixed(1)} s / 60,0 s max
          </span>
        </div>

        <div className="h-2.5 w-full rounded-full bg-[#090B10] overflow-hidden border border-white/[0.06]">
          <div
            className={`h-full transition-all ${
              exceedsLimit ? 'bg-rose-500' : totalDuration >= 55 ? 'bg-emerald-500' : 'bg-[#2563EB]'
            }`}
            style={{ width: `${Math.min(100, (totalDuration / 60) * 100)}%` }}
          />
        </div>

        {exceedsLimit && (
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1 text-xs text-rose-300">
            <span className="inline-flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" />
              Export blockiert: Gesamtlänge überschreitet das 60-Sekunden-Limit.
            </span>
            <button
              onClick={clampTo58Seconds}
              className="min-h-[38px] px-3 rounded-lg bg-rose-500 text-white font-medium"
            >
              Automatisch auf 58s kürzen
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Scene Timeline */}
        <div className="lg:col-span-7 space-y-3">
          {scenes.map((scene) => (
            <div
              key={scene.id}
              className="bg-[#11151E] border border-white/[0.08] rounded-2xl p-4 flex flex-col sm:flex-row gap-4"
            >
              <div className="w-full sm:w-36 aspect-video rounded-xl overflow-hidden bg-[#090B10] border border-white/[0.07] shrink-0">
                {scene.imageUrl ? (
                  <img
                    src={scene.imageUrl}
                    alt={scene.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xs text-slate-600">
                    Kein Frame
                  </div>
                )}
              </div>

              <div className="flex-1 space-y-2.5">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs text-slate-400">
                      Szene {scene.index} · {scene.location}
                    </p>
                    <h3 className="text-sm font-semibold text-white">{scene.title}</h3>
                  </div>
                  <span className="text-xs font-mono text-slate-300 tabular-nums">
                    {scene.durationSec}s
                  </span>
                </div>

                <p className="text-xs text-slate-300 line-clamp-2">{scene.subtitleText}</p>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <select
                    value={scene.cameraMovement}
                    onChange={(e) =>
                      updateCamera(scene.id, e.target.value as FilmScene['cameraMovement'])
                    }
                    className="min-h-[38px] bg-[#090B10] border border-white/[0.1] rounded-lg px-2.5 text-xs text-slate-200"
                  >
                    <option value="Langsamer Zoom-In">Langsamer Zoom-In</option>
                    <option value="Sanfter Zoom-Out">Sanfter Zoom-Out</option>
                    <option value="Schwenk Links">Schwenk Links</option>
                    <option value="Schwenk Rechts">Schwenk Rechts</option>
                    <option value="Vertikaler Tilt">Vertikaler Tilt</option>
                    <option value="Statisch">Statisch</option>
                  </select>

                  <div className="flex items-center gap-2 bg-[#090B10] border border-white/[0.1] rounded-lg px-2.5">
                    <span className="text-[11px] text-slate-400">Dauer:</span>
                    <input
                      type="number"
                      min={3}
                      max={30}
                      value={scene.durationSec}
                      onChange={(e) => updateSceneDuration(scene.id, Number(e.target.value))}
                      className="w-full bg-transparent text-xs font-mono text-white focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Export & Player */}
        <div className="lg:col-span-5 bg-[#11151E] border border-white/[0.08] rounded-2xl p-5 space-y-4 h-fit">
          <h2 className="text-base font-semibold text-white">Video-Export & Qualitätsprüfung</h2>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setAspectRatio('16:9')}
              className={`min-h-[42px] rounded-xl text-xs font-medium border transition-colors ${
                aspectRatio === '16:9'
                  ? 'bg-[#2563EB] border-[#2563EB] text-white'
                  : 'bg-[#090B10] border-white/[0.1] text-slate-300'
              }`}
            >
              16:9 Widescreen
            </button>
            <button
              onClick={() => setAspectRatio('9:16')}
              className={`min-h-[42px] rounded-xl text-xs font-medium border transition-colors ${
                aspectRatio === '9:16'
                  ? 'bg-[#2563EB] border-[#2563EB] text-white'
                  : 'bg-[#090B10] border-white/[0.1] text-slate-300'
              }`}
            >
              9:16 iPhone 16 Pro Max
            </button>
          </div>

          <div className="space-y-2">
            <label className="text-xs text-slate-400 inline-flex items-center gap-1.5">
              <Music className="w-3.5 h-3.5" />
              Soundtrack-Audiospur (Music Studio / Projekt)
            </label>
            <select
              value={selectedAudioUrl}
              onChange={(e) => setSelectedAudioUrl(e.target.value)}
              className="w-full min-h-[42px] bg-[#090B10] border border-white/[0.1] rounded-xl px-3 text-xs text-slate-200"
            >
              <option value="">Ohne Musik-Spur</option>
              {soundtrack && (
                <option value={soundtrack.url}>Music Studio: {soundtrack.title}</option>
              )}
              {projectAudioAssets.map((a) => (
                <option key={a.id} value={a.url}>
                  Projekt-Asset: {a.title}
                </option>
              ))}
            </select>
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-300 min-h-[36px] cursor-pointer">
            <input
              type="checkbox"
              checked={includeVoiceovers}
              onChange={(e) => setIncludeVoiceovers(e.target.checked)}
              className="rounded bg-[#090B10] border-white/20"
            />
            Szenen-Voiceover einmischen ({hasVoiceoverCount} / {scenes.length} Szenen vertont)
          </label>

          <label className="flex items-center gap-2 text-xs text-slate-300 min-h-[36px] cursor-pointer">
            <input
              type="checkbox"
              checked={burnSubtitles}
              onChange={(e) => setBurnSubtitles(e.target.checked)}
              className="rounded bg-[#090B10] border-white/20"
            />
            Deutsche Untertitel direkt in das Video einbrennen
          </label>

          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-xs text-rose-300">
              {error}
            </div>
          )}

          {rendering && (
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-slate-300">
                <span>{progress.label}</span>
                <span className="font-mono">{progress.pct}%</span>
              </div>
              <div className="h-2 rounded-full bg-[#090B10] overflow-hidden">
                <div
                  className="h-full bg-[#2563EB] transition-all"
                  style={{ width: `${progress.pct}%` }}
                />
              </div>
            </div>
          )}

          <button
            onClick={handleExportVideo}
            disabled={rendering || exceedsLimit || !scenes.length}
            className="w-full min-h-[46px] px-4 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] disabled:opacity-50 text-white text-sm font-medium inline-flex items-center justify-center gap-2 transition-colors"
          >
            {rendering ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            {rendering
              ? `Rendere (${totalDuration}s)...`
              : `Video rendern (${totalDuration}s · 0 €)`}
          </button>

          {result && (
            <div className="space-y-3 pt-3 border-t border-white/[0.08]">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span className="inline-flex items-center gap-1.5 text-emerald-400">
                  <Film className="w-3.5 h-3.5" />
                  Export fertig ({result.durationSec}s)
                </span>
                <span className="font-mono">
                  {(result.sizeBytes / (1024 * 1024)).toFixed(2)} MB
                </span>
              </div>
              <video
                src={result.videoUrl}
                controls
                playsInline
                className="w-full rounded-xl bg-black border border-white/[0.08]"
              />
              <a
                href={result.videoUrl}
                download={`zero-film-${currentProject?.title || 'export'}.${
                  result.mimeType.includes('mp4') ? 'mp4' : 'webm'
                }`}
                className="w-full min-h-[44px] rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/[0.08] text-xs font-medium text-white inline-flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                Videodatei herunterladen
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
